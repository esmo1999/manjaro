# my-manjaro-install-script

### This script will install most of the apps and configs i use daily on Manjaro Linux Awesome Edition.

### to install 
```
git clone https://github.com/batvin123/my-manjaro-install-script.git ~/Downloads
```
Note: Run this script from the downloads directory.
